import client from './client'
import { Chapter } from '../types'

export const chapterApi = {
  list: (bookId: number) => client.get<Chapter[]>(`/books/${bookId}/chapters`),
  get: (id: number) => client.get<Chapter>(`/chapters/${id}`),
  create: (bookId: number, data: Partial<Chapter>) => client.post<Chapter>(`/books/${bookId}/chapters`, data),
  update: (id: number, data: Partial<Chapter>) => client.put<Chapter>(`/chapters/${id}`, data),
  delete: (id: number) => client.delete(`/chapters/${id}`),
  generate: (bookId: number) => client.post(`/books/${bookId}/generate`),
  regenerate: (chapterId: number) => client.post(`/chapters/${chapterId}/regenerate`),
  export: (bookId: number, chapterId: number) => client.post(`/books/${bookId}/export/${chapterId}`),
  exportAll: (bookId: number) => client.post(`/books/${bookId}/export-all`),
}